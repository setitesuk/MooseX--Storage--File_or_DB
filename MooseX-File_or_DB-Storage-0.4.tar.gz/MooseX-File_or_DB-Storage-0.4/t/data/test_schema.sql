CREATE TABLE db_test (
  class text,
  col_a text,
  col_b text,
  col_c text,
  col_d text,
  col_index integer primary key autoincrement
  );